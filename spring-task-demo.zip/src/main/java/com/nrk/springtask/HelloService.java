package com.nrk.springtask;

import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class HelloService {
	
	@Value("${app.input.dir:c:\tmp}")
	private String appInputDir;
	
	public List<LocalDate> handleRequest(String s){
		System.out.println(appInputDir);
		return Arrays.asList(
				LocalDate.of(LocalDate.now().getYear(),Month.JANUARY,1),
				LocalDate.of(LocalDate.now().getYear(),Month.MAY,1),
				LocalDate.of(LocalDate.now().getYear(),Month.JUNE,6),
				LocalDate.of(LocalDate.now().getYear(),Month.AUGUST,15),
				LocalDate.of(LocalDate.now().getYear(),Month.DECEMBER,25),
				LocalDate.of(LocalDate.now().getYear(),Month.DECEMBER,31));
	}
	

}
