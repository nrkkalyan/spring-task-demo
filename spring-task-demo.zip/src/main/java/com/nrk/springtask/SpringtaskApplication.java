package com.nrk.springtask;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.task.configuration.EnableTask;
import org.springframework.cloud.task.listener.TaskExecutionListener;
import org.springframework.cloud.task.repository.TaskExecution;

@SpringBootApplication
@EnableTask
public class SpringtaskApplication implements CommandLineRunner, TaskExecutionListener {

	@Autowired
	private HelloService helloService;

	public static void main(String[] args) {
		SpringApplication.run(SpringtaskApplication.class, args);
	}

	@Override
	public void run(String... strings) throws Exception {
		List<LocalDate> handleRequest = helloService.handleRequest("Test");
		System.out.println("Hello World: " + handleRequest);
	}

	@Override
	public void onTaskStartup(TaskExecution taskExecution) {
		System.out.println("Started the task");
	}

	@Override
	public void onTaskEnd(TaskExecution taskExecution) {
		System.out.println("End of the task");
	}

	@Override
	public void onTaskFailed(TaskExecution taskExecution, Throwable throwable) {
		System.out.println("Failed the task : " +taskExecution.getErrorMessage());
	}

}
